"use strict";

var http = require('http');

var options = {
       host: 'ceto.murdoch.edu.au',
       port: 40315,
       path: '/index.html',
       method: 'GET'
};

function onResponse(response)
{
   console.log(response.setEncoding('utf8'));
   response.on('data',
   function(data){
      console.log(data);
   }
   );

   //console.log(response.setEncoding('utf8'));
   response.on('end',
   function(data){
      console.log(data);
   }
   );
}

var client = http.request(options,onResponse);
client.end();
