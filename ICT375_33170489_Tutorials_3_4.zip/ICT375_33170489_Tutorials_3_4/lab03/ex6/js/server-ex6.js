"use strict";

var http = require('http');
var url = require('url');
var qs = require('querystring');
var fs = require('fs');

function onRequest(request, response)
{
   var qstr = url.parse(request.url).query;
   var path = url.parse(request.url).pathname; 
   console.log(path);
   console.log("Request for " + path + " recieved.");
   fs.readFile('index.html', function(err, data)
   {
       if (err) 
       {
         console.error(err)
         return
       }
       else
           {
       response.writeHead(200,{'Content-Type':
                               'text/plain'});
       response.write('Hello client!');
       response.write(data);
       response.end();
            }
   });
}

var server = http.createServer(onRequest);
server.listen(40315,'ceto.murdoch.edu.au');

console.log('Server running http://ceto.murdoch.edu.au:40315/');
console.log('Process ID:', process.pid);
