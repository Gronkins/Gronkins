"use strict";

var http = require('http');
var qs = require('querystring');

function onRequest(request, response)
{
   var qstr = (qs.stringify(request.headers));
   //(4b) console.log(qstr);
   console.log(qs.parse(qstr)["host"]); //4c
   //(4a) = console.log(request.headers);
   response.writeHead(200,{'Content-Type':
                           'text/plain'});
   response.write('Hello client!');
   response.end();
}

var server = http.createServer(onRequest);
server.listen(40315,'ceto.murdoch.edu.au');

console.log('Server running http://ceto.murdoch.edu.au:40315/');
console.log('Process ID:', process.pid);
