"use strict";

var http = require('http');
var qs = require('querystring');

var options = {
       method: 'HEAD',
       host: 'ceto.murdoch.edu.au',
       port: '40315'
};

function onResponse(response)
{
   console.log(response.setEncoding('utf8'));
   response.on('data',
   function(data){
      console.log(data);
   }
   );
}

http.request(options, function(response)
{
      var qstr = (qs.stringify(response.headers));
      console.log(qs.parse(qstr)["content-type"]);
      console.log(qs.parse(qstr)["date"]);
//ex3b this entire function was console.log(qs.stringify(response.headers));
}).end();

