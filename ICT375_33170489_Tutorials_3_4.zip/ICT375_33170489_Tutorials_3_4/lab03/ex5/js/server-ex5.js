"use strict";

var http = require('http');
var url = require('url');
var qs = require('querystring');

function onRequest(request, response)
{
   var qstr = url.parse(request.url).query;
   var path = url.parse(request.url).pathname; 
   console.log(qstr);
   console.log(path);
   console.log(qs.parse(qstr)["foo"]);
   console.log(qs.parse(qstr)["hello"]);
   response.writeHead(200,{'Content-Type':
                           'text/plain'});
   response.write('Hello client!');
   response.end();
}

var server = http.createServer(onRequest);
server.listen(40315,'ceto.murdoch.edu.au');

console.log('Server running http://ceto.murdoch.edu.au:40315/');
console.log('Process ID:', process.pid);
