"use strict";

function reqStart(response, request)
{
  console.log("Request handler 'start' was called.");
  var body = '<html>'+
    '<head>'+
      '<meta http-equiv="Content-Type" content="text/html; '+
      'charset=UTF-8" />'+
    '</head>'+
    '<body>'+
      '<form action="/upload" method="post">'+
      '<textarea name="text" rows="20" cols="60"></textarea>'+
      '<input type="submit" value="Submit text" />'+
      '</form>'+
  '</html>';
  response.writeHead(200, {"Content-Type": "text/html"});
  response.write(body);
  response.end();
}

function reqUpload(response, request)
{
  //request.setEncoding('utf8');
  //var postData = "";
  console.log("Request handler 'upload' was called.");
  response.writeHead(200, {"Content-Type": "text/plain"});
  //response.write("You've sent: " + request + "\n");
  //response.end();
  
  request.setEncoding('utf8');
  var postData = "";
  
  request.addListener('data', function(dataChunk)
  {
    postData += dataChunk;
    console.log("Recieved POST chunk'" + dataChunk + "'.");
    response.write("You've sent: " + postData + "\n");
  });
  request.addListener('end', function()
  {
    //route(pathname, handle, response, postData);
    response.end();
  });
}

exports.reqStart = reqStart;
exports.reqUpload = reqUpload;
