"use strict";

function route(pathname, handle, response, request)
{
  console.log("Routing a request for " + pathname);

  if (typeof handle[pathname] == 'function')
  {
    handle[pathname](response, request);
  }
  else
       {
         console.log("No handler found for: " + pathname);
         response.writeHead(404, {"Content-Type": "text/plain"});
         response.write("Response not found!");
         response.end();
       }
}

exports.route = route;
