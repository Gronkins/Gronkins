"use strict";

var http = require('http');
var url = require('url');
var qs = require('querystring');

function startServer(route, handle)
{
  http.createServer( function (request, response)
  {
    var pathname = url.parse(request.url).pathname;
    console.log("Request for " + pathname + " received.");
    route(pathname, handle, response, request);
   
  }).listen(40315,'ceto.murdoch.edu.au');
  console.log("Server has started at http://ceto.murdoch.edu.au:40315/.");
  console.log("Process ID:", process.pid);
}
exports.startServer = startServer;
