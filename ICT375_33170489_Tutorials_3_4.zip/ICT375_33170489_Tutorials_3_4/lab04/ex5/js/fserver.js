"use strict";

var http = require('http');
var formidable = require('formidable');
var sys = require('sys');
http.createServer(function(request, response)
{
  if (request.url=='/upload' && request.method()=='POST')
  {
    var form = new formidable.IncomingForm();
    form.uploadDir = './tmp';
    form.parse(request, function(error, field, file)
    {
      response.writeHead(200, {'content-type': 'text/plain'});
      response.write('Recieved upload:\n\n');
      response.end(sys.inspect({field: field, file: file}));
    });
    return;
  }

  response.writeHead(200, {'content-type': 'text/html'});
  response.write('<form action="/upload"'+
    'enctype="multipart/form-data" method="post">'+
    '<input type="text" name="title"><br>'+
    '<input type="file" name="upload" multiple="multiple"><br>'+
    '<input type="submit" value="Upload">'+
    '</form>'
  );
  response.end();
}).listen(40315, 'ceto.murdoch.edu.au');
