"use strict";

var exec = require("child_process").exec
var fs = require("fs");
var formidable = require("formidable");
var path = require("path");

function reqStart(request, response)
{
  console.log("Request handler 'start' was called.");
  var body = '<html>'+'<head>'+
  '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />'+
  '</head>'+
  '<body>'+
  '<form action="/upload" enctype="multipart/form-data" method="post">'+
  '<input type="file" name="upload" multiple="multiple" />'+
  '<input type="submit" value="Upload file" />'+
  '</form>'+
  '</body>'+
  '</html>';
  response.writeHead(200, {"Content-Type": "text/html"});
  response.write(body);
  response.end();
}

function reqUpload(request, response/*, postData*/)
{
  console.log("Request handler 'upload' was called.");
  //response.writeHead(200, {"Content-Type": "text/plain"});
  //response.write("You've sent: " +/* postData*/response + "\n");
  console.log("... about to parse ...");
  var form = new formidable.IncomingForm();
  form.uploadDir = './tmp';
  form.parse(request, function(err, field, file)
  {
    console.log("parsing done");
    fs.rename(file.upload.path, "./test.png", function(err)
    {
      if(err)
      {
        fs.unlink("./test.png");
        fs.rename(file.upload.path, "./test.png");
      }
    });
    response.writeHead(200, {"Content-Type": "text/html"});
    response.write("Received image:<br/>");
    response.write("<img src='/show' />");
    response.end();
  });  

}

function reqShow(request, response/*, postData*/)
{
  console.log("Request handler 'show' was called.");
  response.writeHead(200, {"Content-Type": "image/png"});
  fs.createReadStream("./test.png").pipe(response);
}

exports.reqShow = reqShow;
exports.reqStart = reqStart;
exports.reqUpload = reqUpload;
